import React, { useState, useRef, useEffect } from 'react';
import axios from 'axios';
import { Bot, User, Loader2 } from 'lucide-react';
import ChatBox from './components/ChatBox';
import MessageRenderer from './components/MessageRenderer';

const API_URL = "http://127.0.0.1:8000/ask";

function App() {
  const [messages, setMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (query) => {
    const userMessage = { role: 'user', content: query };
    setMessages((prev) => [...prev, userMessage]);
    setIsLoading(true);

    try {
      const response = await axios.post(API_URL, { query });
      const aiResponse = { role: 'assistant', data: response.data };
      setMessages((prev) => [...prev, aiResponse]);
    } catch (error) {
      const errorMsg = "Sorry, I couldn't generate a response. Please check your backend and API key.";
      setMessages((prev) => [...prev, { role: 'assistant', isError: true, content: errorMsg }]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="app-container">
      <header className="header">
        <div className="header-content">
          <div className="header-icon">
            <Bot size={24} />
          </div>
          <h1 className="header-title">Visual AI Assistant</h1>
        </div>
      </header>

      <main className="main-content">
        {messages.length === 0 ? (
          <div className="welcome-screen">
            <div className="welcome-icon">
              <Bot size={56} />
            </div>
            <h2 className="welcome-title">How can I help you visualize today?</h2>
            <p className="welcome-subtitle">
              Ask me to explain concepts, show data, or list steps. I'll respond with clear, beautiful visuals instead of walls of text.
            </p>
            <div className="suggestions-container">
              {['Explain bubble sort flow', 'Show a sample sales chart', 'Explain water cycle steps', 'Show a picture of a cat'].map((q) => (
                <button
                  key={q}
                  onClick={() => handleSendMessage(q)}
                  className="suggestion-btn"
                >
                  {q}
                </button>
              ))}
            </div>
          </div>
        ) : (
          messages.map((msg, index) => (
            <div key={index} className={`message-row ${msg.role === 'user' ? 'user' : 'ai'}`}>
              {msg.role === 'assistant' && (
                <div className="avatar ai">
                  <Bot size={22} />
                </div>
              )}

              <div className="message-content">
                <div className={`message-bubble ${msg.role === 'user' ? 'user' : 'ai'} ${msg.isError ? 'error' : ''}`}>
                  {msg.role === 'user' ? (
                    <p>{msg.content}</p>
                  ) : msg.isError ? (
                    <div className="error-message">
                      <p>{msg.content}</p>
                    </div>
                  ) : (
                    <MessageRenderer response={msg.data} />
                  )}
                </div>
              </div>

              {msg.role === 'user' && (
                <div className="avatar user">
                  <User size={22} />
                </div>
              )}
            </div>
          ))
        )}

        {isLoading && (
          <div className="message-row ai">
            <div className="avatar ai">
              <Bot size={22} />
            </div>
            <div className="message-content">
              <div className="loading-bubble">
                <Loader2 className="spin-icon" size={20} />
                <span>Generating visualization...</span>
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </main>

      <ChatBox onSendMessage={handleSendMessage} isLoading={isLoading} />
    </div>
  );
}

export default App;
