import React, { useState } from 'react';
import { Send, Loader2 } from 'lucide-react';

const ChatBox = ({ onSendMessage, isLoading }) => {
    const [input, setInput] = useState('');

    const handleSubmit = (e) => {
        e.preventDefault();
        if (input.trim() && !isLoading) {
            onSendMessage(input);
            setInput('');
        }
    };

    return (
        <div className="chat-box-container">
            <form onSubmit={handleSubmit} className="chat-box-form">
                <input
                    type="text"
                    value={input}
                    onChange={(e) => setInput(e.target.value)}
                    placeholder="Ask for a diagram, chart, steps, or image..."
                    className="chat-input"
                    disabled={isLoading}
                />
                <button
                    type="submit"
                    disabled={!input.trim() || isLoading}
                    className="chat-send-btn"
                >
                    {isLoading ? <Loader2 className="spin-icon" style={{ color: "white" }} size={20} /> : <Send size={20} />}
                    <span>Send</span>
                </button>
            </form>
        </div>
    );
};

export default ChatBox;
