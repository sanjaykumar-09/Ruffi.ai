import React, { useState } from 'react';
import { Image as ImageIcon, Loader2 } from 'lucide-react';

const ImageComponent = ({ caption, prompt, imageUrl }) => {
    const [loading, setLoading] = useState(true);

    if (!imageUrl) {
        return (
            <div className="image-placeholder">
                <ImageIcon size={56} className="image-icon" />
                <div className="image-caption-container">
                    <h4 className="image-caption-title">Image Conceptualization</h4>
                    <p className="image-caption">
                        "{prompt || caption || "No description provided"}"
                    </p>
                </div>
            </div>
        );
    }

    return (
        <div style={{ width: '100%', display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            {loading && (
                <div style={{ padding: '60px', display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '16px', color: '#64748b' }}>
                    <Loader2 className="spin-icon" size={40} />
                    <p>Generating your image...</p>
                </div>
            )}
            <img
                src={imageUrl}
                alt={prompt || caption || "AI Generated Image"}
                style={{
                    maxWidth: '100%',
                    borderRadius: '12px',
                    display: loading ? 'none' : 'block',
                    boxShadow: '0 4px 6px -1px rgba(0, 0, 0, 0.1)'
                }}
                onLoad={() => setLoading(false)}
            />
            {caption && (
                <p className="image-caption" style={{ marginTop: '16px', textAlign: 'center' }}>
                    {caption}
                </p>
            )}
        </div>
    );
};

export default ImageComponent;
