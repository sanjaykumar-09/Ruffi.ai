import React, { useEffect, useRef, useState } from 'react';
import mermaid from 'mermaid';
import { Loader2, AlertCircle } from 'lucide-react';

mermaid.initialize({
    startOnLoad: false,
    theme: 'default',
    securityLevel: 'loose',
    fontFamily: 'Inter, sans-serif'
});

const DiagramComponent = ({ code }) => {
    const containerRef = useRef(null);
    const [error, setError] = useState(null);
    const [rendering, setRendering] = useState(true);

    useEffect(() => {
        let isMounted = true;

        const renderDiagram = async () => {
            if (!code || !containerRef.current) return;

            setRendering(true);
            setError(null);

            try {
                containerRef.current.innerHTML = '';

                // Remove Markdown wrappers if GPT accidentally included them
                const cleanCode = code.replace(/```mermaid\n?/g, '').replace(/```\n?/g, '').trim();

                const id = `mermaid-${Math.random().toString(36).substr(2, 9)}`;
                const { svg } = await mermaid.render(id, cleanCode);

                if (isMounted) {
                    containerRef.current.innerHTML = svg;
                    setError(null);
                }
            } catch (err) {
                console.error("Mermaid parsing error:", err);
                if (isMounted) {
                    setError("Failed to render diagram. The AI generated invalid Mermaid syntax.");
                }
            } finally {
                if (isMounted) {
                    setRendering(false);
                }
            }
        };

        renderDiagram();

        return () => { isMounted = false; };
    }, [code]);

    if (!code) return null;

    return (
        <div style={{ position: 'relative' }}>
            {rendering && (
                <div className="diagram-loading" style={{ position: 'absolute', inset: 0, backgroundColor: 'rgba(255,255,255,0.8)', zIndex: 10 }}>
                    <Loader2 className="spin-icon" size={32} />
                </div>
            )}

            {error ? (
                <div className="diagram-error">
                    <AlertCircle size={32} style={{ marginBottom: '8px' }} />
                    <strong>{error}</strong>
                    <pre>{code}</pre>
                </div>
            ) : (
                <div ref={containerRef} className="diagram-container" />
            )}
        </div>
    );
};

export default DiagramComponent;
