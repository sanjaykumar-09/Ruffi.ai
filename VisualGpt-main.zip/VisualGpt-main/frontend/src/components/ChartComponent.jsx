import React from 'react';
import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar, Pie, Line } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    PointElement,
    LineElement,
    BarElement,
    ArcElement,
    Title,
    Tooltip,
    Legend
);

const ChartComponent = ({ config }) => {
    if (!config) return null;

    const { type, labels, datasets } = config;

    const chartData = {
        labels: labels || [],
        datasets: (datasets || []).map((ds, i) => ({
            ...ds,
            backgroundColor: ds.backgroundColor || [
                'rgba(59, 130, 246, 0.6)',
                'rgba(16, 185, 129, 0.6)',
                'rgba(245, 158, 11, 0.6)',
                'rgba(239, 68, 68, 0.6)',
                'rgba(139, 92, 246, 0.6)',
            ][i % 5] || 'rgba(59, 130, 246, 0.6)',
            borderColor: ds.borderColor || [
                'rgb(37, 99, 235)',
                'rgb(5, 150, 105)',
                'rgb(217, 119, 6)',
                'rgb(220, 38, 38)',
                'rgb(124, 58, 237)',
            ][i % 5] || 'rgb(37, 99, 235)',
            borderWidth: 1,
        }))
    };

    const options = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'top',
                labels: {
                    font: {
                        family: "'Inter', sans-serif"
                    }
                }
            },
            title: {
                display: false,
            },
        },
    };

    const renderChart = () => {
        switch (type) {
            case 'bar':
                return <Bar data={chartData} options={options} />;
            case 'pie':
                return <Pie data={chartData} options={options} />;
            case 'line':
                return <Line data={chartData} options={options} />;
            default:
                return <Bar data={chartData} options={options} />;
        }
    };

    return (
        <div className="chart-container">
            {renderChart()}
        </div>
    );
};

export default ChartComponent;
