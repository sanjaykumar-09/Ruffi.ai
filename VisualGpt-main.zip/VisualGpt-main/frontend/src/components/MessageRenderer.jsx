import React from 'react';
import DiagramComponent from './DiagramComponent';
import ChartComponent from './ChartComponent';
import StepsComponent from './StepsComponent';
import ImageComponent from './ImageComponent';
import { AlertCircle } from 'lucide-react';

const MessageRenderer = ({ response }) => {
    if (!response || !response.type) {
        return (
            <div className="error-message">
                <AlertCircle size={20} style={{ marginTop: '2px' }} />
                <div>
                    <h3>Invalid Response Format</h3>
                    <p>The AI did not return a valid visual format.</p>
                </div>
            </div>
        );
    }

    const { type, title, content, data } = response;

    const renderVisual = () => {
        switch (type) {
            case 'diagram':
                return <DiagramComponent code={data?.mermaid} />;
            case 'chart':
                return <ChartComponent config={data} />;
            case 'steps':
                return <StepsComponent steps={data?.stepsArray} />;
            case 'image':
                return <ImageComponent caption={content} prompt={data?.prompt} imageUrl={data?.image_url} />;
            default:
                return (
                    <div style={{ padding: '16px', backgroundColor: '#f9fafb', color: '#6b7280', fontStyle: 'italic', borderRadius: '8px' }}>
                        Visual type "{type}" is not supported.
                    </div>
                );
        }
    };

    return (
        <div>
            {(title || content) && (
                <div style={{ marginBottom: '8px' }}>
                    {title && <h3 className="visual-title">{title}</h3>}
                    {content && <p className="visual-content">{content}</p>}
                </div>
            )}
            <div className="visual-card">
                {renderVisual()}
            </div>
        </div>
    );
};

export default MessageRenderer;
