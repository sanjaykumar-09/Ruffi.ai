import React from 'react';

const StepsComponent = ({ steps }) => {
    if (!steps || !Array.isArray(steps) || steps.length === 0) return null;

    return (
        <div className="steps-list">
            {steps.map((step, index) => (
                <div key={index} className="step-item">
                    <div className="step-number">
                        {index + 1}
                    </div>
                    <p className="step-text">{step}</p>
                </div>
            ))}
        </div>
    );
};

export default StepsComponent;
