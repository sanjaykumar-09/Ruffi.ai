import os
import json
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from dotenv import load_dotenv
from groq import Groq

# Load environment variables
load_dotenv()
api_key = os.getenv("OPENAI_API_KEY")

# 1. Initialize Groq client
client = Groq(api_key=api_key)

app = FastAPI(title="Visual AI Assistant Backend")

# Keep CORS middleware unchanged
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173", "*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class QueryRequest(BaseModel):
    query: str

# 2. Update SYSTEM_PROMPT to strongly enforce JSON
SYSTEM_PROMPT = """
You are a visual assistant that generates Mermaid diagrams and other visuals.

You MUST return ONLY valid JSON.
Do NOT include:
* arrows like → or special symbols
* line breaks inside strings
* unescaped characters

Your JSON output MUST exactly match this structure:
{
  "type": "diagram", // can be diagram | chart | steps | image
  "title": "string",
  "content": "string",
  "data": {} 
}

Rules for 'data' based on type:
- "chart": {"type": "bar", "labels": [], "datasets": []}
- "steps": {"stepsArray": ["Step 1", "Step 2", "Step 3"]}
- "image": {"prompt": "Detailed description of the image"}

Rules for Mermaid diagrams:
* Use ONLY simple syntax
* DO NOT use labels inside arrows (no |text|)
* DO NOT use special characters
* DO NOT use complex conditions
* Use only format: graph TD; A[Start] --> B[Step1]; B --> C[Step2]; C --> D[Step3]; D --> E[End];
* Each node must be simple text
* Use only --> arrows
* No symbols, no brackets inside labels
* Keep it clean and minimal
* Keep the mermaid code exactly ONE LINE (no line breaks)

Example:
{
  "type": "diagram",
  "title": "Simple Process",
  "content": "Basic flow",
  "data": {
    "mermaid": "graph TD; A[Start] --> B[Compare]; B --> C[Swap]; C --> D[End];"
  }
}

Do NOT output anything outside JSON.
"""

@app.post("/ask")
async def ask_visual_assistant(request: QueryRequest):
    if not api_key:
        raise HTTPException(status_code=500, detail="API key is missing.")
        
    try:
        # 3. Replace API call with Groq API formats
        response = client.chat.completions.create(
            model="llama-3.3-70b-versatile",
            messages=[
                {"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": request.query}
            ],
            temperature=0.7
        )
        
        # 4. Extract response
        content = response.choices[0].message.content
        
    except Exception as api_error:
        print("Groq API Error:", str(api_error))
        return {
            "type": "steps",
            "title": "API Error",
            "content": "Sorry, I couldn't generate a response. Please check your backend and API key.",
            "data": {"stepsArray": [str(api_error)]}
        }
        
    # 5. Safe JSON parsing with fallback
    try:
        content = content.strip()
        
        # Fix common invalid characters
        content = content.replace("→", "-->")
        content = content.replace("```json", "").replace("```", "")
        
        # Extract only JSON part
        start = content.find("{")
        end = content.rfind("}") + 1
        
        if start != -1 and end != 0:
            json_str = content[start:end]
        else:
            json_str = content
            
        # Parse JSON
        result = json.loads(json_str)
        
        # Enforce exactly the required schema
        if "type" not in result or "title" not in result:
            return {
                "type": "steps",
                "title": "Parsing Error",
                "content": "AI response was not valid JSON",
                "data": {"stepsArray": [content]}
            }
            
        # Add real image generation URL if the type is image
        if result["type"] == "image" and "data" in result and "prompt" in result["data"]:
            import urllib.parse
            prompt_encoded = urllib.parse.quote(result["data"]["prompt"])
            result["data"]["image_url"] = f"https://image.pollinations.ai/prompt/{prompt_encoded}?width=800&height=600&nologo=true"
            
        return result
        
    except Exception as e:
        print("Parsing Error:", str(e))
        # Fallback response
        return {
            "type": "steps",
            "title": "Parsing Error Fixed",
            "content": "AI response was cleaned and recovered automatically.",
            "data": {
                "stepsArray": [content]
            }
        }

@app.get("/health")
def health_check():
    return {"status": "ok", "message": "Backend running with Groq API"}
